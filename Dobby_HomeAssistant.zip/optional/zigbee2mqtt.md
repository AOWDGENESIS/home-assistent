# Zigbee2MQTT

Zigbee2MQTT bleibt bewusst außerhalb des Dobby-Kerns.

Empfohlene Geräte:
- Präsenz-/Bewegungssensoren
- Türen/Fenster
- Wasser-/Lecksensoren
- Steckdosen
- Lampen

Später können Sensoren über Automationen an Dobby angebunden werden, ohne die Kern-Scripts zu verändern.
