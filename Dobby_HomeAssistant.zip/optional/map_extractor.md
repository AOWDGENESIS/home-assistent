# Map Extractor

Die native Ecovacs-Integration zuerst testen.

Nur wenn die native Karten-Entity nicht ausreichend ist:
1. HACS installieren.
2. Map Extractor installieren.
3. Home Assistant neu starten.
4. Die tatsächlich erzeugte Karten-Entity in das Dobby-Dashboard eintragen.

Keine feste `image.dobby_20_map` Entity-ID voraussetzen.
