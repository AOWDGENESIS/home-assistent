# Installationsreihenfolge

## Phase 0 - Backup
Home Assistant Backup/Snapshot erstellen.

## Phase 1 - ECOVACS
Einstellungen -> Geräte & Dienste -> Integration hinzufügen -> Ecovacs.
T30e hinzufügen.

## Phase 2 - Entity prüfen
Entwicklerwerkzeuge -> Zustände.
Prüfen:
`vacuum.dobby_20`

Falls anders:
`input_text.dobby_vacuum_entity` entsprechend ändern.

## Phase 3 - Bereiche
Home-Assistant-Bereiche anlegen:
- Küche
- Wohnzimmer
- Schlafzimmer

Die Robotersegmente den passenden Bereichen zuordnen.

## Phase 4 - Dateien
Den Inhalt dieses ZIPs nach `/config/` kopieren.
Ergebnis:
`/config/packages/dobby/...`

## Phase 5 - configuration.yaml
Den packages-Eintrag aus `configuration.yaml.example` in die vorhandene configuration.yaml integrieren.

## Phase 6 - Konfiguration prüfen
Einstellungen -> System -> Reparaturen / YAML-Konfiguration prüfen.
Nur wenn die Prüfung erfolgreich ist: Neustart.

## Phase 7 - Basis-Test
Über Entwicklerwerkzeuge/Aktionen testen:
- script.dobby_start
- script.dobby_pause
- script.dobby_home
- script.dobby_kueche_saugen

## Phase 8 - Dashboard
Das Dobby-Dashboard sollte automatisch erscheinen, sofern der YAML-Dashboard-Eintrag korrekt übernommen wurde.

## Phase 9 - Ruhezeit
Beispiel:
Beginn 22:00
Ende 08:00

## Phase 10 - Automatik
Erst jetzt:
`input_boolean.dobby_automation_enabled = on`

## Phase 11 - Alexa
Home Assistant Cloud -> Alexa.
Die gewünschten Dobby-Scripts freigeben.

## Phase 12 - HACS
Nur bei Bedarf:
- Map Extractor
- später weitere Komponenten

## Rollback
Wenn etwas nicht stimmt:
1. Automatik ausschalten.
2. Backup wiederherstellen oder die Dobby-Dateien entfernen.
3. configuration.yaml packages-Eintrag entfernen.
4. Home Assistant neu starten.
