# Dobby Home Assistant Automation

Modulare Home-Assistant-Konfiguration für ECOVACS DEEBOT T30e OMNI.

## Ziel
- zentrale Dobby-Steuerung
- Start/Pause/Stop/Home
- Raumreinigung
- Zeitpläne
- Ruhezeiten
- Akku-/Fehler-/Verfügbarkeitsüberwachung
- Wartungshinweise
- Dashboard
- Alexa/Nabu Casa vorbereitete Scripts
- optionale Map-Integration
- keine unnötigen HACS-Abhängigkeiten

## Vor dem Aktivieren
1. ECOVACS-Integration installieren und den Roboter hinzufügen.
2. Prüfen, dass die Entität `vacuum.dobby_20` existiert. Falls nicht, die Entity-ID in `01_helpers.yaml` ändern.
3. Die Dobby-Segmente den Home-Assistant-Bereichen zuordnen.
4. In `01_helpers.yaml` die Area-IDs prüfen:
   - kitchen
   - living_room
   - bedroom
5. Dateien unter `/config/packages/dobby/` kopieren.
6. Den `packages`-Eintrag aus `configuration.yaml.example` in die vorhandene configuration.yaml integrieren.
7. Konfiguration prüfen und Home Assistant neu starten.
8. Erst danach die manuellen Scripts testen.
9. Automatik erst aktivieren, wenn Start/Pause/Home/Raumreinigung funktionieren.
10. Alexa-Scripts über Home Assistant Cloud freigeben.

## Sicherheit
Diese Dateien ersetzen keine vorhandene configuration.yaml. Vor Änderungen immer ein Home-Assistant-Backup erstellen.

## Entity-ID
Die zentrale Entity-ID ist standardmäßig:
`vacuum.dobby_20`

Wenn dein Gerät anders heißt, in `01_helpers.yaml` den Helper `dobby_vacuum_entity` anpassen.

## Karten
Das Dashboard versucht nicht, eine bestimmte Map-Entity zu erzwingen. Die Map-Karte kann nach Ermittlung der tatsächlichen Entity ergänzt werden.

## Hinweise
Ecovacs-Funktionen und Entity-Namen können abhängig von Modell, Firmware und Integration variieren. Nicht vorhandene optionale Attribute werden defensiv behandelt.
